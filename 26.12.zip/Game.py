import sqlite3
import pygame
from random import randrange
from button import button

    

def Create_Table():
    conn = sqlite3.connect('Data.db')
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS feelings (
           feel text,
           info text,
           question1 text,
           Answer1_of_question1 text,
           Answer2_of_question1 text,
           Answer3_of_question1 text,
           CurrectAnswer_of_question1 integar,
           question2 text,
           Answer1_of_question2 text,
           Answer2_of_question2 text,
           Answer3_of_question2 text,
           CurrectAnswer_of_question2 integar,
           question3 text,
           Answer1_of_question3 text,
           Answer2_of_question3 text,
           Answer3_of_question3 text,
           CurrectAnswer_of_question3 integar
        )""")

Create_Table()   

def Insert():#Insert details to DB feelings table
    def insert_into_database(feel,info,question1,Answer1_of_question1,Answer2_of_question1,Answer3_of_question1,CurrectAnswer_of_question1,question2,Answer1_of_question2,Answer2_of_question2,Answer3_of_question2,CurrectAnswer_of_question2,question3,Answer1_of_question3,Answer2_of_question3,Answer3_of_question3,CurrectAnswer_of_question3):
        conn = sqlite3.connect('Data.db')
        c = conn.cursor()
        with conn:
            c.execute("INSERT INTO feelings VALUES (:feel,:info, :question1,:Answer1_of_question1,:Answer2_of_question1,:Answer3_of_question1,:CurrectAnswer_of_question1,:question2,:Answer1_of_question2,:Answer2_of_question2,:Answer3_of_question2,:CurrectAnswer_of_question2,:question3,:Answer1_of_question3,:Answer2_of_question3,:Answer3_of_question3,:CurrectAnswer_of_question3)", {'feel':feel,'info':info, 'question1':question1,'Answer1_of_question1':Answer1_of_question1,'Answer2_of_question1':Answer2_of_question1,'Answer3_of_question1':Answer3_of_question1,'CurrectAnswer_of_question1':CurrectAnswer_of_question1,'question2':question2,'Answer1_of_question2':Answer1_of_question2,'Answer2_of_question2':Answer2_of_question2,'Answer3_of_question2':Answer3_of_question2,'CurrectAnswer_of_question2':CurrectAnswer_of_question2,'question3':question3,'Answer1_of_question3':Answer1_of_question3,'Answer2_of_question3':Answer2_of_question3,'Answer3_of_question3':Answer3_of_question3,'CurrectAnswer_of_question3':CurrectAnswer_of_question3})
            conn.commit()    

    insert_into_database('happy','Hapiness_Complite.png','Happy1_Complete.PNG','Angry','Smile','Cry',2,'Happy2_Complete.PNG','Happy','Sad','Anger',1,'Happy3_Complete.PNG','Anger','Sad','Happy',2)
    insert_into_database('sad','Sad_info.png','Sad1_Complete.PNG','Sad','fear','Anger',1,'Sad2_Complete.png','Happy','Sad','Anger',2,'Sad3_Complete.png','Anger','Sad','fear',2)
    insert_into_database('angry','Angry_Complite.png','Anger1_Complete.PNG','Happy','Sad','Angry',3,'Anger2_Complete.png','Anger','Happy','Fear',1,'Anger3_Complete.PNG','Fear','Sad','Anger',3) 
    insert_into_database('fear','Fear_Complite.png','Fear1_Complete.PNG','Happy','Sad','Fear',3,'Fear2_Complete.PNG','Sad','Fear','Anger',2,'Fear3_Complete.PNG','Fear','Sad','Happy',1)
Insert()
def Reset_dictionary():
    for x in level:
        if level[x]==15:
            level[x]=0
def UpdateCard():#Updating from DB the Cards and buttons
    global x
    x=arr_feelings[indexCard]
    Reset_dictionary()
    with sqlite3.connect("Data.db") as db:
        cursor=db.cursor()
    find_feelings=("SELECT * FROM feelings WHERE feel=?")
    cursor.execute(find_feelings,[(x)])
    result=cursor.fetchall()
    global Card_info,Card_question,Button1,Button2,Button3,questionButton,color,ans
    Card_info=pygame.image.load(result[0][1])
    Card_question=pygame.image.load(result[0][2+level[x]])
    Button1=button((255,255,255),300,430,250,40,result[0][3+level[x]])
    Button2=button((255,255,255),300,530,250,40,result[0][4+level[x]])
    Button3=button((255,255,255),300,630,250,40,result[0][5+level[x]])
    questionButton=button((255,255,255),300,680,250,100,'Question')
    color=randrange(0,255)
    ans=result[0][6+level[x]]



def Random():#return random number to indexCard 
    while True:
        rand=randrange(0,len(arr_feelings))
        if(rand!=indexCard):
            return rand        
        
def RedWindow():#Building the buttons
    if(indexTypeCard==0):
        screen.fill((color,150,100))
        questionButton.draw(screen,(0,0,0))
    else:
        screen.fill((color,131,180))
        Button1.draw(screen,(0,0,0))
        Button2.draw(screen,(0,0,0))
        Button3.draw(screen,(0,0,0))


def feel_Card():#Building the cards
    if(indexTypeCard==0):
        screen.blit(Card_info,(200,10))
    else:
        screen.blit(Card_question,(140,10))
        
      
       
        


pygame.init()
pygame.display.set_caption("Moment of Emotion") 
screen=pygame.display.set_mode((800,800)) 
arr_feelings=['happy','sad','angry','fear']
level={'happy':0,'sad':0,'angry':0,'fear':0}
indexCard=0
indexTypeCard=0
UpdateCard()
running=True

Mistake1=True
Mistake2=True
Mistake3=True


while running: #Loop keep the window on
    
    for event in pygame.event.get():
        pos=pygame.mouse.get_pos()
        if event.type==pygame.MOUSEBUTTONDOWN:#Pressing on button
            if questionButton.isOver(pos) :
                if(indexTypeCard==0):
                    indexTypeCard+=1 
                    UpdateCard()
            elif Button1.isOver(pos) and indexTypeCard==1:
                    if not ans==1:
                        Mistake1=False
                    else:
                        Mistake1=True
                        Mistake2=True
                        Mistake3=True 
                        level[x]+=5      
                        indexCard=Random()
                        indexTypeCard=0
                        UpdateCard()
            elif Button2.isOver(pos) and indexTypeCard==1:
                    if not ans==2:
                        Mistake2=False
                    else:
                        Mistake1=True
                        Mistake2=True
                        Mistake3=True 
                        level[x]+=5      
                        indexCard=Random()
                        indexTypeCard=0
                        UpdateCard()
            elif Button3.isOver(pos) and indexTypeCard==1:
                    if not ans==3:
                        Mistake3=False
                    else:
                        Mistake1=True
                        Mistake2=True
                        Mistake3=True 
                        level[x]+=5      
                        indexCard=Random()
                        indexTypeCard=0
                        UpdateCard()
                    
        if event.type==pygame.MOUSEMOTION: #button change color
            
            if questionButton.isOver(pos) and indexTypeCard==0:
                questionButton.color=(255,0,0)
            else:
                questionButton.color=(0,255,0)
            if Mistake1:
                
                if Button1.isOver(pos):
                    Button1.color=(255,0,0)
                else:
                    Button1.color=(0,255,0)
            else:
                Button1.color=(255,0,0)
            if Mistake2:
                if Button2.isOver(pos):
                    Button2.color=(255,0,0)
                else:
                    Button2.color=(0,255,0)
            else:
                Button2.color=(255,0,0)
            if Mistake3:
                if Button3.isOver(pos):
                    Button3.color=(255,0,0)
                else:
                    Button3.color=(0,255,0)
            else:
                Button3.color=(255,0,0)
        
        if event.type==pygame.QUIT:
            running=False
            
    
    RedWindow()
    feel_Card()
    
    pygame.display.flip()
